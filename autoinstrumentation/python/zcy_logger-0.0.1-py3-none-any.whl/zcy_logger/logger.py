import json
import logging
import os
import sys
import traceback
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any, Dict, Optional
from opentelemetry import trace

from loguru import logger as _logger

# Context vars fallback if OpenTelemetry is not present or span is not set
_ctx_trace_id: ContextVar[Optional[str]] = ContextVar("trace_id", default=None)
_ctx_span_id: ContextVar[Optional[str]] = ContextVar("span_id", default=None)

try:
    # Optional OpenTelemetry dependency
    from opentelemetry.trace import get_current_span
except Exception as  e:
    # pragma: no cover - optional import
    print(e)
    get_current_span = None  # type: ignore


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _hex_id(num: int, length: int) -> str:
    return f"{num:0{length}x}"


def _get_trace_and_span() -> Dict[str, Optional[str]]:
    # Try OpenTelemetry first
    if get_current_span is not None:
        try:

            span = trace.get_current_span()
            if span and span.get_span_context():
                ctx = span.get_span_context()
                # Use valid trace/span or None if invalid
                if getattr(ctx, "is_valid", None) and ctx.is_valid:
                    trace_id = _hex_id(ctx.trace_id, 32)
                    span_id = _hex_id(ctx.span_id, 16)
                    return {"trace_id": trace_id, "span_id": span_id}
                else:
                    # Some versions expose is_valid as property, others as method
                    if getattr(ctx, "is_valid", None) is True or (
                            callable(getattr(ctx, "is_valid", None)) and ctx.is_valid()
                    ):
                        trace_id = _hex_id(ctx.trace_id, 32)
                        span_id = _hex_id(ctx.span_id, 16)
                        return {"trace_id": trace_id, "span_id": span_id}
        except Exception as e:
            print(e.__str__())
            pass
    # Fallback to contextvars
    return {"trace_id": _ctx_trace_id.get(), "span_id": _ctx_span_id.get()}


def set_trace_context(trace_id: Optional[str] = None, span_id: Optional[str] = None) -> None:
    """Manually set trace/span IDs for contexts without OpenTelemetry.

    Parameters:
        trace_id: 32-hex chars string. If shorter, it will be left as-is.
        span_id: 16-hex chars string.
    """
    if trace_id is not None:
        _ctx_trace_id.set(trace_id)
    if span_id is not None:
        _ctx_span_id.set(span_id)


def clear_trace_context() -> None:
    _ctx_trace_id.set(None)
    _ctx_span_id.set(None)


class InterceptHandler(logging.Handler):
    """Redirect standard logging logs to loguru."""

    def emit(self, record: logging.LogRecord) -> None:  # pragma: no cover
        try:
            # Map logging level to loguru level
            level = _logger.level(record.levelname).name
        except Exception:
            level = record.levelno
        # Find caller from where logging was called to preserve file/line
        frame, depth = logging.currentframe(), 2
        while frame and frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1
        _logger.bind(logger_name=record.name).opt(depth=depth, exception=record.exc_info).log(
            level, record.getMessage()
        )


def _serialize(record: Dict[str, Any]) -> str:  # pragma: no cover - formatting function
    # Build a unified JSON log line
    exc = record["exception"]
    process_info = record["process"]
    thread_info = record["thread"]

    payload: Dict[str, Any] = {
        "time": (record.get("time").isoformat() if record.get("time") else _now_iso()),
        "level": record["level"].name,
        "message": record["message"],
        "trace_id": record["extra"]["trace_id"],
        "span_id": record["extra"]["span_id"],
        "logger": record["extra"].get("logger_name") or record.get("name"),
        "module": record["module"],
        "function": record["function"],
        "line": record["line"],
        "process": f"{process_info.id if hasattr(process_info, 'id') else process_info}:{process_info.name if hasattr(process_info, 'name') else 'unknown'}",
        "thread": f"{thread_info.id if hasattr(thread_info, 'id') else thread_info}:{thread_info.name if hasattr(thread_info, 'name') else 'unknown'}",
    }

    # 检查是否有预格式化的异常信息（通过 patcher 添加）
    if "formatted_exception" in record["extra"]:
        payload["exception"] = record["extra"]["formatted_exception"]
    elif exc:
        # 如果还有原始异常（不应该发生，但作为后备）
        exc_type, exc_value, exc_traceback = exc
        payload["exception"] = {
            "type": exc_type.__name__ if hasattr(exc_type, "__name__") else str(exc_type),
            "message": str(exc_value),
            "stacktrace": str(exc_value),  # 降级处理
        }

    # Include any user-defined extras
    for k, v in record["extra"].items():
        if k not in ("service", "logger_name"):
            payload.setdefault(k, v)

    return json.dumps(payload, ensure_ascii=False)


def init_logging(
        level: str | int = "INFO",
        json_output: bool = True,
        include_backtrace: bool = False,
        diagnose: bool = False,
) -> None:
    """Initialize Loguru-based unified logging.

    - JSON output with trace_id/span_id fields.
    - Intercepts standard logging, so third-party libs (Flask, Django, SQLAlchemy, Uvicorn, FastAPI) are captured.
    - OpenTelemetry trace/span IDs are used if available; otherwise contextvars fallback.

    Parameters:
        service_name: Optional logical service name; can also be set via env SERVICE_NAME.
        level: Log level for the root sink.
        json_output: If True, output logs as JSON; else use a human-readable format.
        include_backtrace: Include rich backtrace for exceptions (costly in prod).
        diagnose: Loguru diagnose option for debugging (avoid in prod).
    """
    # Remove default handlers
    _logger.remove()

    fmt = (
        "<green>{time:YYYY-MM-DDTHH:mm:ss.SSSZ}</green> | "
        "<level>{level: <8}</level> | "
        "trace={extra[trace_id]} span={extra[span_id]} | "
        "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
        "<level>{message}</level>"
    )

    def patcher(record: Dict[str, Any]) -> None:
        # Inject trace/span into extras so non-JSON format can reference them
        ids = _get_trace_and_span()
        record.setdefault("extra", {})
        record["extra"].setdefault("trace_id", ids.get("trace_id"))
        record["extra"].setdefault("span_id", ids.get("span_id"))
        # 在进入队列之前格式化异常信息（因为 traceback 对象无法被 pickle）
        if record.get("exception"):
            exc_type, exc_value, exc_traceback = record["exception"]
            if exc_traceback is not None:
                stacktrace_lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
                stacktrace_str = "".join(stacktrace_lines)
            elif hasattr(exc_value, "__traceback__") and exc_value.__traceback__ is not None:
                stacktrace_lines = traceback.format_exception(exc_type, exc_value, exc_value.__traceback__)
                stacktrace_str = "".join(stacktrace_lines)
            else:
                stacktrace_str = f"{exc_type.__name__ if hasattr(exc_type, '__name__') else str(exc_type)}: {str(exc_value)}"

            # 将格式化后的异常信息存储在 extra 中
            record["extra"]["formatted_exception"] = stacktrace_str

    _logger.configure(patcher=patcher)

    if json_output:
        # Use custom sink for JSON output
        def json_sink(message):
            # message.record contains the log record dict
            record = message.record
            serialized = _serialize(record)
            sys.stdout.write(serialized + "\n")
            sys.stdout.flush()

        _logger.add(
            json_sink,
            level=level,
            backtrace=include_backtrace,
            diagnose=diagnose,
            enqueue=True,
        )
    else:
        # Use human-readable format
        _logger.add(
            sys.stdout,
            level=level,
            backtrace=include_backtrace,
            diagnose=diagnose,
            enqueue=True,
            format=fmt,
        )

    # Intercept standard logging
    intercept = InterceptHandler()
    logging.root.handlers = [intercept]
    logging.root.setLevel(level if isinstance(level, int) else logging.getLevelName(level))

    # Common third-party loggers to route
    for name in (
            "uvicorn",
            "uvicorn.error",
            "uvicorn.access",
            "fastapi",
            "sqlalchemy",
            "sqlalchemy.engine",
            "aiohttp",
            "flask",
            "werkzeug",
            "django",
            "django.request",
            "celery",
    ):
        logging.getLogger(name).handlers = [intercept]
        logging.getLogger(name).propagate = False
        logging.getLogger(name).setLevel(logging.root.level)
    logging.info("init logger success")
    _logger.remove = lambda *args, **kwargs: print("skip remove")
    _logger.add = lambda *args, **kwargs: print("skip add add")
    _logger.configure = lambda *args, **kwargs: print("skip configure")


# Public logger for direct use
logger = _logger.bind()
